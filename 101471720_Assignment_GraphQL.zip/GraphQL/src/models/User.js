const mongoose = require("mongoose");

const required = {
    type    : String,
    required: true
};
const unique = {
    type    : String,
    required: true,
    unique  : true
};
const create_date = {
    type    : Date,
    default : Date.now,
    get : (value) => {
        return new Date(value).toLocaleDateString("ja-JP");
    }
};
const update_date = {
    type: Date,
    get: (value) => {
        return new Date(value).toLocaleDateString("ja-JP");
    }
};

module.exports = mongoose.model("User", new mongoose.Schema({
    username    : unique,
    email       : unique,
    password    : required,
    created_at  : create_date,
    updated_at  : update_date
}));
