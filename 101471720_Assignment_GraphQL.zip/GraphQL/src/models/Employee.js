const mongoose = require("mongoose");

const required = {
    type    : String,
    required: true
};
const unique = {
    type    : String,
    required: true,
    unique  : true
};
const gender_enum = [
    "Male",
    "Female",
    "Other"
]
const gender = {
    type    : String,
    enum    : gender_enum,
    required: true
};
const salary = {
    type    : Number,
    required: true,
    min     : 1000
};
const create_date = {
    type    : Date,
    default : Date.now,
    get : (value) => {
        return new Date(value).toLocaleDateString("ja-JP");
    }
};
const update_date = {
    type: Date,
    get: (value) => {
        return new Date(value).toLocaleDateString("ja-JP");
    }
};

module.exports = mongoose.model("Employee", new mongoose.Schema({
    first_name      : required,
    last_name       : required,
    department      : required,
    designation     : required,
    date_of_joining : required,
    email           : unique,
    gender          : gender,
    salary          : salary,
    employee_photo  : { type : String },
    created_at      : create_date,
    updated_at      : update_date
}));
